---
utid: 20170302113757
date: 2017-03-02 11:37:57
title: "آینده از نگاه من"
_index: my-vision-for-the-future
category: Futurist
image: /assets/article_images/future/future.jpg
---
"آینده از نگاه من"، شماره دو

این پست برای تست آدرس دهی فایل‌هایی با آدرس مشابه نوشته شده.
